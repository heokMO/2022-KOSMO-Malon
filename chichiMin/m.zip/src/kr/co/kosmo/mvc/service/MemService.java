package kr.co.kosmo.mvc.service;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.co.kosmo.mvc.dao.MemDAO;
import kr.co.kosmo.mvc.dto.MemVO;

@Repository
public class MemService implements MemDAO{
	@Autowired
	private SqlSessionTemplate ss;
	
	@Override
	public void joinIn(MemVO vo) {
		ss.insert("member.joinIn",vo);
	}

	@Override
	public int memIdchk(String id) {
		int result = ss.selectOne("member.idchk", id);
		return result;
	}
	
	@Override
	public MemVO myInfo(String memId) {
		MemVO vo1 = ss.selectOne("member.myInfo",memId);
		return vo1;
	   }

	@Override
	public int memberDelete(MemVO vo) {
		int cnt = ss.delete("member.memberDelete",vo);
		return cnt;
	}

	@Override
	public void updateMember(MemVO vo) {
		ss.update("member.updateMember", vo); 
	}

}

